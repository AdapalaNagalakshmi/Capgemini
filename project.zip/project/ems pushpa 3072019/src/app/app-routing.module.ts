import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './page/menu.component';
import { RegistrationComponent } from './registration.component';
import { LoadsingleComponent } from './page/loadsingle.component';
import { LoadbulkComponent } from './page/loadbulk.component';
import { ModifyComponent } from './page/modify.component';
import { DeletesingleComponent } from './page/deletesingle.component';
import { ViewComponent } from './page/view.component';
import { DeleteselectComponent } from './page/deleteselect.component';
import { DeleteallComponent } from './page/deleteall.component';

 

const routes: Routes = [
  {path:'loginpage',component:LoginComponent},
  {path :'menupage',component:MenuComponent},
  {path :'loadsingle',component:LoadsingleComponent},
  {path :'loadbulk',component:LoadbulkComponent}, 
  {path :'registrationpage',component:RegistrationComponent},
  {path :'modifypage',component:ModifyComponent},
  {path:'viewpage',component:ViewComponent},
  {path :'deletesingle',component:DeletesingleComponent},
  {path :'deleteselect',component:DeleteselectComponent},
  {path :'deleteall',component:DeleteallComponent},
  
  {path :'', redirectTo:'/menupage', pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  //imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
