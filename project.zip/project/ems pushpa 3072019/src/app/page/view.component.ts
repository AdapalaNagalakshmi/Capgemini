import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { EmployeeService } from '../employee.service';
import { IEmployee } from './Employee.interface';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  constructor(private router:Router,private service:EmployeeService) { }
  empdata:IEmployee[];
  empdata1:IEmployee[];
  model:any={};
  model1:IEmployee[];
  
  ngOnInit() {
  
 this.service.getAllEmployee().subscribe((data:any)=>this.empdata=data);
   this.empdata1=this.empdata;
  }
  addtotables(ind){
  var index=this.model1.indexOf(ind);
  if(index>-1){
    this.model1.splice(index,1)
  }
  else{
    this.model1.push(ind);
  }
  //this.service.getAllEmployee().subscribe((data:any)=>this.empdata=data);
  
  } 
  onCancel(){
    this.router.navigate(['./menupage']);
  }
  /* goHome(){
    this.router.navigate(['./menupage']);
  }
  onLoadSingle(){
    this.router.navigate(['./loadsingle']);
  }
  onLoadBulk(){
    this.router.navigate(['./loadbulk']);
  } 
  goLogout(){
    this.router.navigate(['./loginpage']);
  }

  onModify(){
    this.router.navigate(['./modifypage']);
  }
  
  onView(){
    this.router.navigate(['./viewpage']);
  }

  onDeleteSingle(){
    this.router.navigate(['./deletesingle']);
  } */
 
}
