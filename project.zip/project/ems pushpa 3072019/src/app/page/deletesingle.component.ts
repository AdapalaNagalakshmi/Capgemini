import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-deletesingle',
  templateUrl: './deletesingle.component.html',
  styleUrls: ['./deletesingle.component.css']
})
export class DeletesingleComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  onCancel(){
    this.router.navigate(['/menupage']);
  }
  goLogout(){
    this.router.navigate(['/loginpage']);
  }
}
