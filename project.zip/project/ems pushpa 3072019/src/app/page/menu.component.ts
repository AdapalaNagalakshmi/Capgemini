import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  goHome(){
    this.router.navigate(['./menupage']);
  }
  
  onLoadSingle(){
    console.log("hgdshyeg");
    this.router.navigate(['./loadsingle']);
  }
  
  onLoadBulk(){
    this.router.navigate(['./loadbulk']);
  } 
  
  goLogout(){
    this.router.navigate(['./loginpage']);
  }

  onModify(){
   // console.log("ghd");
    this.router.navigate(['./modifypage']);
  }
  
  onView(){
    this.router.navigate(['./viewpage']);
  }

  onDeleteSingle(){
    //console.log("ghdlkjhgfh");
    this.router.navigate(['./deletesingle']);
  }

  onSelect(){
    //console.log("ghdlkjhgfhhgujhg");
    this.router.navigate(['./deleteselect']);
  }
  
  onSelectAll(){
    this.router.navigate(['./deleteall']);
  }

}