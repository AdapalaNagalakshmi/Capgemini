import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }
  getAllEmployee(){
    return this.http.get("http://localhost:5689/employee/get");
   }
   addEmployee(data:any){
     let input={"employee_Id":data.eid,"firstName":data.fname,"lastName":data.lname,"gender":data.gen,
     "date_of_Birth":data.dob,"date_of_Join":data.doj,"branch_Id":data.bid,"manager_Id":data.mid};
   
     return this.http.post("http://localhost:5689/employee/add",input);
   }
  
   deleteEmployees(eid) { 
     //let input={"empId":eid} 
     return this.http.delete("http://localhost:5689/employee/delete/"+ eid);  
   }  
}
