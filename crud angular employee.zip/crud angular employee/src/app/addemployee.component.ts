import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './app.employeeservice';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent {
  router: any;
  constructor(private service:EmployeeService){}

  model:any={};
  addEmployee():any{
    console.log(this.model);
  this.service.addEmployee(this.model).subscribe();
  this.router.navigate(['/addemployees']);
  }
  ngOnInit(){
}
}
