import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './app.employeeservice';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  router: any;

  constructor(private service:EmployeeService) { }
  model:any={};
  searchById():any{
    console.log(this.model);
  this.service.searchById(this.model).subscribe();
  this.router.navigate(['/searchemployeeById']);
  }

  ngOnInit() {
  }

}
