import {Component} from '@angular/core';
import {EmployeeService} from './app.employeeservice';
@Component({


    selector:'show-app',
    
    
    templateUrl:'app.show.component.html'
})
export class ShowComponent {
    constructor(private service:EmployeeService){}
    empdata:any[]=[];
empId:number;
    ngOnInit(){
        this.service.getAllEmployees().subscribe((data:any)=>this.empdata=data);

    }
    DeleteEmployee(empId){
        let emp = this.empdata.indexOf(empId);
        this.empdata.splice(emp,1);
        this.service.DeleteEmployee(emp).subscribe();
     
         
     }
}