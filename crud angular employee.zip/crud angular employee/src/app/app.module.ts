﻿import {ShowComponent} from './app.show.component';

import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {HttpClientModule} from '@angular/common/HTTP';
import {FormsModule} from '@angular/forms';
import { AddemployeeComponent } from './addemployee.component';
import { SearchComponent } from './search.component';
import { UpdateemployeeComponent } from './updateemployee.component';





@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        
        
      
    ],
    declarations: [
        AppComponent,
        ShowComponent,
        AddemployeeComponent,
        SearchComponent,
        UpdateemployeeComponent



   ],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }