import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './app.employeeservice';

@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {
  router: any;

  constructor(private service:EmployeeService) { }
  model:any={};
  updateEmployee():any{
    console.log(this.model);
  this.service.updateEmployee(this.model).subscribe();
this.router.navigate('/updateemployee')
  }
  ngOnInit() {
  }

}
