import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { post } from '../../node_modules/@types/selenium-webdriver/http';
@Injectable ({
    

    providedIn: 'root'
})
export class EmployeeService {
    [x: string]: any;
    constructor(private http:HttpClient)
    {}
    getAllEmployees(){
        return this.http.get("http://localhost:9765/emplist/getalldata");
    }
    addEmployee(data:any){
        let input = new FormData();
        input.append("empId",data.empId);
        input.append("empName",data.empName);
        input.append("empSalary",data.empSalary);
        return this.http.post("http://localhost:9765/emplist/addemployeedata",data);
    }
DeleteEmployee(empId){
return this.http.delete("http://localhost:9765/emplist/deletedata/" +empId);
}
}