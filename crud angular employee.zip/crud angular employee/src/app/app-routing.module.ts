import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddemployeeComponent } from 'src/app/addemployee.component';
import { UpdateemployeeComponent } from 'src/app/updateemployee.component';
import { SearchComponent } from 'src/app/search.component';


const routes: Routes = [

  {path:'addemployees',component:AddemployeeComponent },
  {path:'updateemployees',component:UpdateemployeeComponent},
  {path:'searchemployeebyid',component:SearchComponent}
 
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
