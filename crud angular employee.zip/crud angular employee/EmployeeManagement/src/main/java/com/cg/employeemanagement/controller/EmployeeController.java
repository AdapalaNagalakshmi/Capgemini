package com.cg.employeemanagement.controller;

import java.util.List;

import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.service.EmployeeService;

@RestController	
@RequestMapping("/emplist")

  @CrossOrigin(origins = "http://localhost:4200")
 public class EmployeeController {
	@Autowired
	EmployeeService employeeservice;
	//@RequestMapping(value="/getalldata", method=RequestMethod.GET) is similar to getmapping. In this just we write method name also
	@GetMapping("/getalldata")

	public ResponseEntity<List<Employee>> getALLEmployees() {
		List<Employee> myList=employeeservice.showAllEmployee();
		if(myList.isEmpty()) {
			return  new ResponseEntity("NO employee",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Employee>>(myList,HttpStatus.OK);
	}
	@PostMapping("/createdata")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {
		Employee data = employeeservice.addEmployee(emp);
		if(data==null)
		{
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(HttpStatus.OK);
	}
	
	@PutMapping("/updatedata")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp) {
		Employee p1 = employeeservice.updateEmployee(emp);
		if(p1==null)
		{
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Employee>(HttpStatus.OK);
	}
	
	@DeleteMapping("/deletedata")
	 public void deleteEmployee(@RequestParam("empId") Integer eid)
	 {
		 employeeservice.deleteEmployee(eid);
		
	}
	
	@GetMapping("/getdata")
	public ResponseEntity<Employee> searchByEmployeeId(@RequestParam("eid") Integer e)
	{
		Employee e1 = employeeservice.searchByEmployeeId(e);
		if(e1==null)
		{
			return new ResponseEntity("data not found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(e1,HttpStatus.OK);
	}

	 @GetMapping("/getdata/{empName}")
	 
	 public ResponseEntity<Employee> searchByEmployeeName( @PathVariable("empName") String eName)
	 
	 {
		 Employee e2 = employeeservice.searchByEmployeeName(eName);
		 if(e2==null)
		 {
			 return new ResponseEntity("name not there", HttpStatus.NOT_FOUND);
		 }
		return new ResponseEntity<Employee>(e2, HttpStatus.OK);
		 
	 }
	
	
}

 
