package com.cg.employeemanagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement.dao.EmployeeRepository;
import com.cg.employeemanagement.dto.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService {
 
	@Autowired
	EmployeeRepository employeerepository;
	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeerepository.findAll();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeerepository.save(emp);
	}

	@Override
	public Employee searchByEmployeeId(int eid) {
		// TODO Auto-generated method stub
		Employee e1= employeerepository.findById(eid).get();
		 return  e1;
		}
	
	@Override
	
	public Employee searchByEmployeeName(String eName)
	{
		List<Employee> emp=employeerepository.findAll();
		List<Employee> emp1=new ArrayList<Employee>();
		
		for (Employee employee : emp) {
			if((employee.getEmpName().toLowerCase()).equals(eName)) {
				emp1.add(employee);
			}
				}
		return (Employee) emp1;
		

		/* return employeerepository.findOne(eName).get(); */
		
	}

	@Override
	public void deleteEmployee(int eid)
	{
		 employeerepository.deleteById(eid);
		
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		Employee emp1 = employeerepository.findById(emp.getEmpId()).get();
		emp1.setEmpId(emp.getEmpId());
		emp1.setEmpName(emp.getEmpName());
		emp1.setEmpSalary(emp.getEmpSalary());
		return employeerepository.save(emp1);
	}

	@Override
	public Employee searchByEmployeeSalary(Double eSalary) {
		// TODO Auto-generated method stub
		List<Employee> emp=employeerepository.findAll();
		List<Employee> emp1=new ArrayList<Employee>();
		for (Employee employee : emp) {
			if(employee.getEmpSalary()==eSalary) {
				emp1.add(employee);
			}
		}
		return (Employee) emp1;
		
	}

	
	




}
