package com.cg.employeemanagement.service;

import java.util.List;

import com.cg.employeemanagement.dto.Employee;

public interface EmployeeService {
	public List<Employee> showAllEmployee();
	public Employee addEmployee(Employee emp);
	public Employee searchByEmployeeId(int eid);
	public void deleteEmployee(int eid);
	public Employee updateEmployee(Employee emp);
    public 	Employee searchByEmployeeName(String eName);
	public Employee searchByEmployeeSalary(Double eSalary);
	

}
