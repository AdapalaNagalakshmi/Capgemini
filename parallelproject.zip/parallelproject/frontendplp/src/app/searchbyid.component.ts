import { Component, OnInit } from '@angular/core';
import { SearchserviceService } from './searchservice.service';

@Component({
  selector: 'app-searchbyid',
  templateUrl: './searchbyid.component.html',
  styleUrls: ['./searchbyid.component.css']
})
export class SearchbyidComponent implements OnInit {
model:any={};
searchiddata:any[]=[];
a:boolean=true;
b:boolean=false;
c:boolean=false;
d:boolean=false;
  constructor(private service:SearchserviceService) { }

  ngOnInit() {
  }
onSubmit(){
  this.a=false;
  this.b=true;
 this.service.searchById(this.model.sid,this.model.oid).subscribe((data:any)=>{this.searchiddata=data;
  });
 
}
onupdate(model){
  console.log(model);
  this.a=false;
  this.b=false;
  this.d=true;
  if((this.model.status)=="completed"||(this.model.status)=="initiated"||(this.model.status)=="notapplicable"||(this.model.status)=="notinitiated"){
  
    this.service.updatedelivery(this.model.sid,this.model.oid,this.model.status).subscribe((data:any)=>alert(data));                 
}
}
}
