import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SearchserviceService {

  constructor(private http:HttpClient) { }

  searchById(storeId,orderId){
    
      return this.http.get("http://localhost:9858/api/getid?sid="+storeId+"&oid="+orderId);      
  }
  searchByName(name){
    return this.http.get("http://localhost:9858/api/getname?pname="+name);
  }
  updatedelivery(sid,oid,status){
    console.log(sid);
    console.log(oid);
    console.log(status);
    return this.http.put("http://localhost:9858/api/update?sid="+sid+"&oid="+oid+"&status="+status,sid);
  }
}
