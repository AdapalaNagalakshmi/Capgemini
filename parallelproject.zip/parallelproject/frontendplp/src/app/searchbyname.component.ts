import { Component, OnInit } from '@angular/core';
import { SearchserviceService } from './searchservice.service';
import { empty } from '../../node_modules/rxjs';

@Component({
  selector: 'app-searchbyname',
  templateUrl: './searchbyname.component.html',
  styleUrls: ['./searchbyname.component.css']
})
export class SearchbynameComponent  {
  searchnamedata:any[]=[];
  items:any[]=[];
  a:boolean=true;
  b:boolean=false;
  constructor(private service:SearchserviceService) { }

  searchname(name){
    this.a=false;
  this.b=true;
 
 this.service.searchByName(name).subscribe((data:any)=>{this.searchnamedata=data;
  
 });
 


  }
}
