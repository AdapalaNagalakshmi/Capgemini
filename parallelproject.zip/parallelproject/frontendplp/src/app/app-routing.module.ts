import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchbyidComponent } from './searchbyid.component';
import { SearchbynameComponent } from './searchbyname.component';



const routes: Routes = [
  { path:'searchbyid', component:SearchbyidComponent},
  { path :'searchbyname',component:SearchbynameComponent},

  {path:'',redirectTo:'',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
