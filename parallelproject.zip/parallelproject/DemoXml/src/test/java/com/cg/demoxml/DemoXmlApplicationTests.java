package com.cg.demoxml;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.demoxml.dto.PurchaseDetails;
import com.cg.demoxml.service.DemoXmlService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoXmlApplicationTests {
	 @Autowired
	  DemoXmlService demoxmlservice; 

	@ParameterizedTest
	@ValueSource(ints = {111, 112, 113, Integer.MAX_VALUE}) 
	public void contextLoads(int number) {
		PurchaseDetails p=new PurchaseDetails();
		p.setOrderId(111);
  assertEquals("correctdata", p, p.getOrderId());		
		  	
    }
	}
	


