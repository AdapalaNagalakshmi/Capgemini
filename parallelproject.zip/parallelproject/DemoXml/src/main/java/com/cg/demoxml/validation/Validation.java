package com.cg.demoxml.validation;
import java.io.File;
import java.io.IOException;


import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

public class Validation {

	
	/*
	 * public static void main(String args[]) throws SAXException, IOException {
	 * boolean flag=true; try { validate("tr.xml","Validation.xsd"); } catch
	 * (SAXException e) { flag=false; } catch (IOException e) { flag=false; }
	 * System.out.println("xml file is valid:" +flag); }
	 */
	public static boolean validate(String xsdPath, File xmlPath) throws SAXException, IOException 
	{
	 try {
	  
	//SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_INSTANCE_NS_URI);
	//((schemaFactory.newSchema(new File(validationFile))).newValidator()).validate(new StreamSource(new File(xmlFile)));
	SchemaFactory factory = SchemaFactory.newInstance( XMLConstants.W3C_XML_SCHEMA_NS_URI );
	Schema schema = factory.newSchema(new File(xsdPath));
	javax.xml.validation.Validator  validator=schema.newValidator();
	validator.validate(new StreamSource(xmlPath));
	System.out.println("valid xml");
	} catch(SAXException e) 
	 {
	 System.out.println("Exception:" +e.getMessage());
	 return false;
	 } catch (IOException e) {
	  System.out.println("Exception:" +e.getMessage());
	  return false;
	 }
	 
	 return true;
	   }

	}

	
	

