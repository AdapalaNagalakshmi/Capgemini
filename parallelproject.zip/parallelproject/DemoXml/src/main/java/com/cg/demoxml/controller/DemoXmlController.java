package com.cg.demoxml.controller;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;

import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import com.cg.demoxml.dao.DemoXmlDao;
import com.cg.demoxml.dto.Item;
import com.cg.demoxml.dto.PurchaseDetails;
import com.cg.demoxml.dto.Transaction;
import com.cg.demoxml.dto.TransactionDetails;
import com.cg.demoxml.service.DemoXmlService;


@RestController
@RequestMapping("/api")
//@CrossOrigin(origins={"http://localhost:4200"})
public class DemoXmlController {
	
	@Autowired
	DemoXmlService demoxmlservice;
	
@PostMapping("/createdata")

public  ResponseEntity<String> insertData() throws JAXBException {
	
    demoxmlservice.insertData();
  
	return  new ResponseEntity<String>("successfully added", HttpStatus.CREATED);

}
@PutMapping("/update")
public ResponseEntity<String> update(@RequestParam("sid") Integer sid,@RequestParam("oid") Integer oid,
		@RequestParam("status") String deliverystatus) {
	String list=demoxmlservice.update(sid, oid, deliverystatus);
	if(list.isEmpty()) {
		return new ResponseEntity("no order updated",HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<String>("updated successfully!!!!",HttpStatus.OK);	 
		
}

@GetMapping("/getid")
public ResponseEntity<TransactionDetails> getByOrderId(@RequestParam("sid") Integer storeId,@RequestParam("oid") Integer orderId ){
	TransactionDetails list=demoxmlservice.getByOrderId(storeId, orderId);

	if(list==null) {
		return new ResponseEntity("no item found",HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<TransactionDetails>(list,HttpStatus.OK);
	
	 
}

@GetMapping("/getname")

public ResponseEntity<List<PurchaseDetails>> getByName(@RequestParam ("pname") String name ){
	List<PurchaseDetails> list=demoxmlservice.getByName(name);

	if(list.isEmpty()) {
		return new ResponseEntity("no item found with item_name"+name,HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<List<PurchaseDetails>>(list,HttpStatus.OK);
	
}

}