package com.cg.demoxml.dto;


import java.util.List;


public class TransactionDetails {

	private String BusinessDayDate;

	private List<PurchaseDetails> purchaseDetails;

	private List<DeliveryDetails> deliveryDetails;
	
	private String paymentMode;
	
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getBusinessDayDate() {
		return BusinessDayDate;
	}
	public void setBusinessDayDate(String businessDayDate) {
		BusinessDayDate = businessDayDate;
	}
	

	public List<PurchaseDetails> getPurchaseDetails() {
		return purchaseDetails;
	}
	public void setPurchaseDetails(List<PurchaseDetails> purchaseDetails) {
		this.purchaseDetails = purchaseDetails;
	}
	

	public List<DeliveryDetails> getDeliveryDetails() {
		return deliveryDetails;
	}
	public void setDeliveryDetails(List<DeliveryDetails> deliveryDetails) {
		this.deliveryDetails = deliveryDetails;
	}
	
	
	
	public TransactionDetails(String businessDayDate, List<PurchaseDetails> purchaseDetails,
			List<DeliveryDetails> deliveryDetails, String paymentMode) {
		super();
		BusinessDayDate = businessDayDate;
		this.purchaseDetails = purchaseDetails;
		this.deliveryDetails = deliveryDetails;
		this.paymentMode = paymentMode;
	}
	public TransactionDetails() {
		// TODO Auto-generated constructor stub
	}
	
		

}
