package com.cg.demoxml.dao;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.xml.sax.SAXException;

import com.cg.demoxml.dto.Item;
import com.cg.demoxml.dto.PurchaseDetails;
import com.cg.demoxml.dto.Transaction;
import com.cg.demoxml.dto.TransactionDetails;

public interface IDemoXmlDao {
	public void insertData() throws JAXBException;
	public String update(Integer sid, Integer oid, String deliverystatus);
	public TransactionDetails getByOrderId(Integer storeId, Integer orderId);
	public List<PurchaseDetails> getByName(String name);

	

}
