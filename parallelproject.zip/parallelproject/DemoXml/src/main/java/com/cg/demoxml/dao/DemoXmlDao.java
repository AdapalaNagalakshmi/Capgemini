package com.cg.demoxml.dao;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.demoxml.dto.DeliveryDetails;
import com.cg.demoxml.dto.Item;
import com.cg.demoxml.dto.PurchaseDetails;
import com.cg.demoxml.dto.Transaction;
import com.cg.demoxml.dto.TransactionDetails;

@Repository
public class DemoXmlDao implements IDemoXmlDao {
	
	public static double a=0;

	@Autowired
	MongoTemplate mongo;
	@Override
	public void insertData() {
	
		File file=new File("transaction.xml");
		JAXBContext jaxContext;
		try {
			jaxContext = JAXBContext.newInstance(Transaction.class);
		
		Unmarshaller unmarshaller = jaxContext.createUnmarshaller();
		Transaction transaction = (Transaction) unmarshaller.unmarshal(file);
		
		mongo.insert(transaction);
		Transaction creditTransaction=new Transaction();
        Transaction cashTransaction=new Transaction();
		Transaction debitTransaction=new Transaction();
		 JAXBContext content=JAXBContext.newInstance(Transaction.class); 
		 Marshaller marshaller=content.createMarshaller();
		 File file1=new File("C:\\Users\\pusalava\\Desktop\\CreditCardTransaction.xml");
		 File file2=new File("C:\\Users\\pusalava\\Desktop\\CardTransaction.xml");
		 File file3=new File("C:\\Users\\pusalava\\Desktop\\DebitCardTransaction.xml");
		 
		 List<TransactionDetails> creditTransactions=new ArrayList<>();
		 List<TransactionDetails> cashTransactions=new ArrayList<>();
		 List<TransactionDetails> debitTransactions=new ArrayList<>();
		
		 List<TransactionDetails> dt=transaction.getDetail();
		
		 marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		 for (TransactionDetails transactionDetails : dt) {
			  if(transactionDetails.getPaymentMode().equalsIgnoreCase("credit")) {
				
				   creditTransactions.add(transactionDetails);
				   creditTransaction.setDetail(creditTransactions);
				   creditTransaction.setRetailStoreId(((Transaction) transaction).getRetailStoreId()); 
				   marshaller.marshal(creditTransaction, file1);
				  }
		
			  else if(transactionDetails.getPaymentMode().equalsIgnoreCase("cash")) {
					
					   cashTransactions.add(transactionDetails);
					   cashTransaction.setDetail(cashTransactions);
					   cashTransaction.setRetailStoreId(((Transaction) transaction).getRetailStoreId()); 
					   marshaller.marshal(cashTransaction, file2);
					  }
			
			  else {
				  debitTransactions.add(transactionDetails);
				   debitTransaction.setDetail(debitTransactions);
				   debitTransaction.setRetailStoreId(((Transaction) transaction).getRetailStoreId()); 
				   marshaller.marshal(debitTransaction, file3);
			  }
			  
			  
		 }
		  
		
		
		 marshaller.marshal(creditTransaction, System.out);
		 marshaller.marshal(debitTransaction, System.out);
		 marshaller.marshal(cashTransaction, System.out);
		 
		  mongo.save(transaction);
		
		
	}
	catch (JAXBException e) {
	
		e.printStackTrace();
	}
		
	}
	@Override
	public String update(Integer sid, Integer oid, String deliverystatus) {
		
		 List<Transaction> transaction=mongo.findAll(Transaction.class);
	       for (int i = 0; i < transaction.size(); i++) {
	        Transaction tr=transaction.get(i);
	        Integer storeid= tr.getRetailStoreId();
	        
	        if(storeid.equals(sid)) {
	         List<TransactionDetails> td=tr.getDetail();
	         for (int j = 0; j < td.size(); j++) {
				    TransactionDetails detail=td.get(j);
				    List<PurchaseDetails> pd=detail.getPurchaseDetails();
				    for (PurchaseDetails purchaseDetails : pd) {
				    	Integer orderid=purchaseDetails.getOrderId();
				    	
				    	if (orderid.equals(oid)) {
						     List<DeliveryDetails> deliverydetails=detail.getDeliveryDetails();
						     
						     for (DeliveryDetails deliveryDetails : deliverydetails) {
						    	 deliveryDetails.setDeliverystatus(deliverystatus);
							}
						     
						     mongo.save(tr);
						     return "sucessfullyupdated";
						     
						    }
					}
				    
	   }
	         
	        }
	  
	 }
	 return "please enter a valid details";
	}
	

	


@Override
public TransactionDetails getByOrderId(Integer storeId,Integer orderId ) {
	
	
	List<Transaction> tra=mongo.findAll(Transaction.class);
	TransactionDetails dt=new TransactionDetails();
	  for (int i = 0; i < tra.size(); i++) {
	        Transaction tr=tra.get(i);
	        Integer storeid= tr.getRetailStoreId();       
	List<PurchaseDetails> purchaseDetails=new ArrayList<>();
	List<Item> items=new ArrayList<>();
	if(storeId.equals(storeid)) {
		  List<TransactionDetails> td=tr.getDetail();
		     for (int j = 0; j < td.size(); j++) {
			    TransactionDetails tdetail=td.get(j);
		purchaseDetails=tdetail.getPurchaseDetails();
		                           for (PurchaseDetails pd: purchaseDetails) {
			Integer oid=pd.getOrderId();
			
			        if(orderId.equals(oid)) {
				List<DeliveryDetails> d=tdetail.getDeliveryDetails();
				dt=tdetail;
				  }
			}
	}

	}
	}
	return dt;
}

@Override
public List<PurchaseDetails> getByName(String item) {
	List<Transaction> transactionlist= mongo.findAll(Transaction.class);
	List<PurchaseDetails> updatedpdlist=new ArrayList<PurchaseDetails>();
	for (int i = 0; i < transactionlist.size(); i++) {
		Transaction trnsaction= transactionlist.get(i);
		List<TransactionDetails> tdlist=trnsaction.getDetail();
		for (int j = 0; j < tdlist.size(); j++) {
			TransactionDetails tdetails=tdlist.get(j);
			List<PurchaseDetails> purchasedetails=tdetails.getPurchaseDetails();
			 for (PurchaseDetails purchase : purchasedetails) {
				List<Item> itemlist= purchase.getItem();
			 
			List<Item> updatedil=new ArrayList<Item>();
			for (int k = 0; k < itemlist.size(); k++) {
				Item item1= itemlist.get(k);
				if (item1.getName().equalsIgnoreCase(item)) {
					a+=item1.getAmount();
					updatedil.add(item1);	
				}	
			}
			 
			
			if (updatedil.size()!=0) {
				PurchaseDetails updatedpd=new PurchaseDetails();
				updatedpd.setOrderId(purchase.getOrderId());
				updatedpd.setTotal_amount(a);
				updatedpd.setItem(updatedil);
				updatedpdlist.add(updatedpd);
			}
			
		}
			 a=0;
		}
	}
	return updatedpdlist;
}
}






 







			

