package com.cg.demoxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.cg.demoxml")
@SpringBootApplication
public class DemoXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoXmlApplication.class, args);
		System.out.println("demoxml");
	}

}
