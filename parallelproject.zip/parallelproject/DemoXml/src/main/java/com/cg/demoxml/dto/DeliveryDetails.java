package com.cg.demoxml.dto;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.mongodb.core.mapping.Document;



public class DeliveryDetails {

	private String deliverystatus;

	public String getDeliverystatus() {
		return deliverystatus;
	}

	public void setDeliverystatus(String deliverystatus) {
		this.deliverystatus = deliverystatus;
	}
	
	public DeliveryDetails() {
		// TODO Auto-generated constructor stub
	}

	public DeliveryDetails(String deliverystatus) {
		super();
		this.deliverystatus = deliverystatus;
	}


	
}
