package com.cg.demoxml.service;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.cg.demoxml.dao.DemoXmlDao;
import com.cg.demoxml.dto.Item;
import com.cg.demoxml.dto.PurchaseDetails;
import com.cg.demoxml.dto.Transaction;
import com.cg.demoxml.dto.TransactionDetails;

@Service
public class DemoXmlService implements IDemoXmlService{
	
@Autowired
DemoXmlDao demoxmldao;

@Override
public String update(Integer sid, Integer oid, String deliverystatus) {
	// TODO Auto-generated method stub
	return demoxmldao.update(sid, oid, deliverystatus);
}

@Override
public TransactionDetails getByOrderId(Integer storeId, Integer orderId) {
	
	return demoxmldao.getByOrderId(storeId, orderId);
}

@Override
public List<PurchaseDetails> getByName(String name) {
	// TODO Auto-generated method stub
	
	return demoxmldao.getByName(name);
}


@Override
public void insertData() throws JAXBException {
	
		demoxmldao.insertData(); 
			
		}

	
}












