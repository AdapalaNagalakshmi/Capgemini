package com.cg.demoxml.dto;
import org.springframework.data.annotation.Id;

import java.util.List;


import javax.xml.bind.annotation.XmlRootElement;


import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "order_Details")
@XmlRootElement(name = "Transaction")

public class Transaction {
	
private Integer retailStoreId;

    private List<TransactionDetails> detail;

    
   

	public Integer getRetailStoreId() {
	return retailStoreId;
}




public void setRetailStoreId(Integer retailStoreId) {
	this.retailStoreId = retailStoreId;
}



public List<TransactionDetails> getDetail() {
	return detail;
}




public void setDetail(List<TransactionDetails> detail) {
	this.detail = detail;
}




	public Transaction() {
		// TODO Auto-generated constructor stub
	}




	public Transaction(Integer retailStoreId, List<TransactionDetails> detail) {
		super();
		this.retailStoreId = retailStoreId;
		this.detail = detail;
	}






	
}
