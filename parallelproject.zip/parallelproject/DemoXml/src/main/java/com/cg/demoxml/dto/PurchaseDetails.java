package com.cg.demoxml.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;

import org.springframework.data.annotation.Id;


public class PurchaseDetails {
	
	private Integer orderId;
	
	private List<Item> item;
	private Double total_amount;
	
	
	public PurchaseDetails() {
		// TODO Auto-generated constructor stub
	}
	@XmlAttribute(name="orderId")
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public List<Item> getItem() {
		return item;
	}
	public void setItem(List<Item> item) {
		this.item = item;
	}
	public Double getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(Double total_amount) {
		this.total_amount = total_amount;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [orderId=" + orderId + ", item=" + item + ", total_amount=" + total_amount + "]";
	}


	
	
}
