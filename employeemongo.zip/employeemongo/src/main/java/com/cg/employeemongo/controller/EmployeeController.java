package com.cg.employeemongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemongo.dto.Employee;
import com.cg.employeemongo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeservice;
	
	@PostMapping("/addemp")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {
		Employee e=employeeservice.addEmployee(emp);
		if(e==null) {
			return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(emp,HttpStatus.OK);
	}

	@GetMapping("/getall")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		
		List<Employee> emps=employeeservice.getAllEmployee();
		if(emps.isEmpty()) {
			return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Employee>>(emps,HttpStatus.OK);
		
	}
	
	@PutMapping("/updateall")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp) {
		Employee emp1= employeeservice.updateEmployee(emp);
		if(emp1==null) {
			return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(emp,HttpStatus.OK);
	}
	
	@DeleteMapping("/del")
	public ResponseEntity deleteEmployee(@RequestParam("eid") int empId) {
		if(empId==-1) {
			return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
		}
		
		employeeservice.deleteEmployee(empId);
		return new ResponseEntity("data deleted",HttpStatus.OK);

		
	}
	
	@GetMapping("/searchid")
	public ResponseEntity<Employee> searchByEmployeeId(@RequestParam("eid") int empId) {
		Employee emp=employeeservice.searchEmployeeById(empId);
		if(emp==null) {
			return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(emp,HttpStatus.OK);
	}
	
	
	@GetMapping("/getbyname")
	public ResponseEntity<List<Employee>> searchByName(@RequestParam("name") String ename){

	List<Employee> e=employeeservice.searchEmployeeByName(ename);
	
	if(e.isEmpty()) {
		return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<List<Employee>>(e,HttpStatus.OK);
		
	}
	
	@GetMapping("/getbysal")
	public ResponseEntity<List<Employee>> searchEmployeeBySalary(@RequestParam("sal") Double sal){
	
	List<Employee> emp=employeeservice.searchEmployeeBySalary(sal);
	if(emp.isEmpty()) {
		return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
		
	}
	
	@GetMapping("/search")
	public ResponseEntity<List<Employee>> search(){
		List<Employee> emp=employeeservice.search();
		if(emp.isEmpty()) {
			return new ResponseEntity("Data Not Found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
			
	}
}
