package com.cg.employeemongo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employeemongo.dto.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	
	@Autowired
	MongoTemplate mongotemplate;
	
//	private static final String COLLECTION="Employee.class";

	@Override
	public List<Employee> getAllEmployee() {
		
		return mongotemplate.findAll(Employee.class);
	}

	@Override
	public Employee addEmployee(Employee emp) {
	
		return mongotemplate.insert(emp);
	}

	

	@Override
	public Employee updateEmployee(Employee emp) {
		System.out.println("in dao ....."+emp);
		mongotemplate.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(int empId) {
	
		mongotemplate.remove(mongotemplate.findById(empId,Employee.class));
		
	}
	@Override
	public Employee searchEmployeeById(int empId) {
		
		//return mongotemplate.findById(empId,Employee.class);
		
		Query query=Query.query(Criteria.where("empId").is(empId));
		//Query query=Query.query(Criteria.where("empSalary").gte(10000));
		Employee emp=mongotemplate.findOne(query,Employee.class);
		
		
		return emp;
		
	}

	@Override
	public List<Employee> searchEmployeeByName(String name) {
		List<Employee> emp=mongotemplate.findAll(Employee.class);
		List<Employee> emp1=new ArrayList<Employee>();
		for (Employee employee : emp) {
			if(employee.getEmpName().equals(name)) {
			emp1.add(employee);
			}
		}
		return emp1;
	}

	@Override
	public List<Employee> searchEmployeeBySalary(Double sal) {
		
		List<Employee> emp=mongotemplate.findAll(Employee.class);
		List<Employee> emp1=new ArrayList<Employee>();
		for (Employee employee : emp) {
			if(Double.compare(employee.getEmpSalary(),sal)==0) {
			emp1.add(employee);
			}
		}
		return emp1;
	}

	@Override
	public List<Employee> search() {
		Query query=Query.query(Criteria.where("empSalary").gte(10000));
		List<Employee> emps=mongotemplate.find(query,Employee.class,"employee_mongo");
		return emps;
	}

}
