package com.cg.employeemongo.service;

import java.util.List;

import com.cg.employeemongo.dto.Employee;

public interface EmployeeService {
	
 public List<Employee> getAllEmployee();
 public Employee addEmployee(Employee emp);
 
 public Employee searchEmployeeById(int empId);
 public List<Employee> searchEmployeeByName(String name);
 public List<Employee> searchEmployeeBySalary(Double sal);
 
 public List<Employee> search();
 
 
 public Employee updateEmployee(Employee emp);
 public void deleteEmployee(int empId);
 
}
