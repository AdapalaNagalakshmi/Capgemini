package com.cg.employeemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement.dao.EmployeeRepository;
import com.cg.employeemanagement.dto.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService {
 
	@Autowired
	EmployeeRepository employeerepository;
	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeerepository.findAll();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeerepository.save(emp);
	}

	@Override
	public Employee searchByEmployeeId(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}



}
