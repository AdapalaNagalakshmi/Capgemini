package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.ProductDao;
import com.cg.product.dto.Product;


@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao repo;
	
	@Override
	public Product addproduct(Product product) {
		
		return repo.addproduct(product);
	}

	@Override
	public void Delete(Integer id) {
		repo.Delete(id);
		
	}

	@Override
	public List<Product> getAll() {
		
		return repo.getAll();
	}

	@Override
	public Product getBId(Integer id) {
		
		return repo.getBId(id);
	}

	@Override
	public Product update(Integer id, Double price) {
	
		return repo.update(id, price);
	}
	


}
