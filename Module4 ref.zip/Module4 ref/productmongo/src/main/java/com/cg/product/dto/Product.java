package com.cg.product.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "productpurchase")
public class Product {
	
	@Id
	private Integer id;
	private String item;
	private Double price;
	private Date date;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", item=" + item + ", price=" + price + ", date=" + date + "]";
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
