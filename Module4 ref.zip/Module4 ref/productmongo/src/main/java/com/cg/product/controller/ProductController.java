package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductService service;
	
	
	@PostMapping("/add")
	public Product addProduct(@RequestBody Product product) {
		return service.addproduct(product);
	}
	
	@DeleteMapping("/del")
	public void delByid(@RequestParam("id") Integer id ) {
		service.Delete(id);
	}
	
	
	@GetMapping("/getall")
	public List<Product> getAll(){
		return service.getAll();
	}
	
	@GetMapping("/getbyid")
	public Product getById(@RequestParam("id") Integer id) {
		return service.getBId(id);
	}
	
	@PostMapping("/update")
	public Product update(@RequestParam("id") Integer id,@RequestParam("price") Double price) {
		return service.update(id, price);
	}

}
