package com.cg.product.service;

import java.util.List;

import com.cg.product.dto.Product;

public interface ProductService {
	
public Product addproduct(Product product);
	
	public void Delete(Integer id);
	
	public List<Product> getAll();
	
	public Product getBId(Integer id);
	
	public Product update(Integer id,Double price);

}
