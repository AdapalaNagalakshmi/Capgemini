package com.cg.product.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;


@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	MongoTemplate mt;
	
	@Override
	public Product addproduct(Product product) {
		Date d=new Date();
		product.setDate(d);
		mt.insert(product);
		return product;
	}

	@Override
	public void Delete(Integer id) {
		Product product=mt.findById(id, Product.class);
		mt.remove(product);
		
	}

	@Override
	public List<Product> getAll() {
		// TODO Auto-generated method stub
		return mt.findAll(Product.class);
	}

	@Override
	public Product getBId(Integer id) {
		Product product=mt.findById(id, Product.class);
		return product;
	}

	@Override
	public Product update(Integer id, Double price) {
		Product product=mt.findById(id, Product.class);
		product.setPrice(price);
		mt.save(product);
		return product;
	}

}
