package com.cg.employeemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	EmployeeService employeeservice;
	
	@GetMapping("/getall")
	public ResponseEntity<List<Employee>> getAllEmployee(){
		List<Employee> emp= employeeservice.showAllEmployee();
		if(emp.isEmpty()) {
			return new ResponseEntity("no dataa....",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Employee>>(emp,HttpStatus.OK);
	}
	

	@PostMapping("/add")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {
		Employee empl= employeeservice.addEmployee(emp);
		if(empl==null)
		{
			return new ResponseEntity("please insert data...",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Employee>(empl,HttpStatus.OK);
	}
	
	@PutMapping("/update")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp) {
		Employee empl=employeeservice.updateEmployee(emp);
		if(empl==null)
		{
			return new ResponseEntity("please insert data...",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity<Employee>(empl,HttpStatus.OK);
	}
	 
	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteEmployee(@RequestParam("eid") Integer emp) {
		 employeeservice.deleteEmployee(emp);
		 if(emp==null)
		 {
			 return new ResponseEntity("please give the data",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<String>("deleted",HttpStatus.OK);
	}

	@GetMapping("/search")
	public ResponseEntity<Employee> searchEmployee(@RequestParam("eid") Integer emp) {
		System.out.println(emp);
		 Employee empl=employeeservice.searchEmployeeById(emp);
		 if(empl==null)
		 {
			 return new ResponseEntity("data not found...",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<Employee>(empl,HttpStatus.OK);
	}
	
	@GetMapping("/searchbysalary")
	public ResponseEntity<List<Employee>> searchEmployee(@RequestParam("eid") Double salary) {
		System.out.println(salary);
		 List<Employee> empl= employeeservice.searchEmployeeBySalary(salary);
		 if(empl.isEmpty())
		 {
			 return new ResponseEntity("data not found...",HttpStatus.NOT_FOUND);
		 }
		 return new ResponseEntity<List<Employee>>(empl,HttpStatus.OK);
	}
	

}
