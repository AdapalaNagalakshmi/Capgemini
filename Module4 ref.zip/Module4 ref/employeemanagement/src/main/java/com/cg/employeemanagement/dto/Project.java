package com.cg.employeemanagement.dto;

public class Project {
	private String name;
	private Integer id;
	private String dep;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDep() {
		return dep;
	}
	public void setDep(String dep) {
		this.dep = dep;
	}
	@Override
	public String toString() {
		return "Project [name=" + name + ", id=" + id + ", dep=" + dep + "]";
	}
	public Project() {
		
	}
	
	

}
