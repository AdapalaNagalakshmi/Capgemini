package com.cg.employeemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement.dao.EmployeeDao;
import com.cg.employeemanagement.dto.Employee;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	
	@Autowired
	EmployeeDao rep;
	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return rep.addEmployee(emp);
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return rep.showAllEmployee();
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return rep.searchEmployeeById(empId);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return rep.updateEmployee(emp);
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		rep.deleteEmployee(empId);
		
	}

	@Override
	public List<Employee> searchEmployeeBySalary(Double salary) {
		// TODO Auto-generated method stub
		return rep.searchEmployeeBySalary(salary);
	}

}
