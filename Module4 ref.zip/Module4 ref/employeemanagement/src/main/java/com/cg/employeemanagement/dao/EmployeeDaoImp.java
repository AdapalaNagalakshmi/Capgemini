package com.cg.employeemanagement.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employeemanagement.dto.Employee;


@Repository
public class EmployeeDaoImp implements EmployeeDao {

	
	@Autowired
	MongoTemplate mongotemplate;
	
	
	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		mongotemplate.insert(emp);
		return emp;
				
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(Employee.class);
	}
 
	@Override
	public Employee searchEmployeeById(int empId) {
		
		Employee emp= mongotemplate.findById(empId, Employee.class);
		//Query query=Query.query(Criteria.where("empId").is(empId));
		//Query query=Query.query(Criteria.where("salary").gte(5000));
	   // Employee emp=mongotemplate.findOne(query, Employee.class);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		mongotemplate.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(int empId) {
	Employee emp=mongotemplate.findById(empId, Employee.class);
	mongotemplate.remove(emp);
		
	}

	@Override
	public List<Employee> searchEmployeeBySalary(Double salary) {
		// TODO Auto-generated method stub
		Query query=Query.query(Criteria.where("salary").gte(salary));
	  List<Employee> emp=mongotemplate.find(query, Employee.class,"Employee_Management");
		return emp;
	}


}
