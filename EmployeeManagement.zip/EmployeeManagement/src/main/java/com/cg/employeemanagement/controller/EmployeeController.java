package com.cg.employeemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.service.EmployeeService;

@RestController
@RequestMapping("/emplist")
 @CrossOrigin(origins = "http://localhost:4200") 
public class EmployeeController {
	@Autowired
	EmployeeService employeeservice;
	//@RequestMapping(value="/getalldata", method=RequestMethod.GET) is similar to getmapping. In this just we write method name also
	@GetMapping("/getalldata")

	public ResponseEntity<List<Employee>> getALLEmployees() {
		List<Employee> myList=employeeservice.showAllEmployee();
		if(myList.isEmpty()) {
			return  new ResponseEntity("NO employee",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Employee>>(myList,HttpStatus.OK);
	}
	@PostMapping("/createdata")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee emp) {
		Employee data = employeeservice.addEmployee(emp);
		if(data==null)/* {
		return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND)	;
		}
		return new ResponseEntity<Employee>(HttpStatus.OK);
		
	}*/
		{
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(HttpStatus.OK);
}
}
/*
 * @GetMapping("/getalldata/{eid}") public Employee
 * searchByEmployeeId( @PathVariable= {int empId) { return null;
 * 
 * } }
 */
