package com.cg.employeemongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemongo.dto.Employee;
import com.cg.employeemongo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeService employeeservice;
	@GetMapping("/getdata")
	public List<Employee> getAllEmployee()
	{
	return employeeservice.showAllEmployee();
	}

	
	@PostMapping("/add_data")
	 public Employee addEmployee(@RequestBody Employee emp) {
		return employeeservice.addEmployee(emp);
		  }
	@PostMapping("/updateall")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp)
	{
		Employee e1 = employeeservice.updateEmployee(emp);
		if(e1==null) {
			return new ResponseEntity("that emp id is not there so cant be updated",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity(e1, HttpStatus.OK);
		/* return employeeservice.updateEmployee(emp); */
		
	}
	
	@DeleteMapping("/deletedata")
	public void deleteEmployee (@RequestParam("eid") int empId) {
		/*
		 * Employee e2 = employeeservice.deleteEmployee(empId); if(e2==null) { return ;
		 * } System.out.println("Controller" +empId);
		 */
		employeeservice.deleteEmployee(empId);
		
		}
	
	@GetMapping("/searchid")
	public ResponseEntity searchByEmployeeId(@RequestParam("eid") int empId) {
		 
	Employee e1 = employeeservice.searchEmployeeById(empId);
	if (e1==null)
	{
		return new ResponseEntity("id not there", HttpStatus.NOT_FOUND);
	}
	
		return new ResponseEntity("data added" +e1, HttpStatus.OK);
		}
}
