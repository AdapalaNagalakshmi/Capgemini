package com.cg.employeemongo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.cg.employeemongo.dto.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(emp);
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(Employee.class);
	}

	@Override
	public Employee searchEmployeeById(int empId) {
		/*
		 * Query query = Query.query(Criteria.where("empId").is(empId));
		 */
		
		/* Employee e= mongotemplate.findOne(query, Employee.class); */
		
		
		  Query query2 = Query.query(Criteria.where("empSalary").gte(5000));
		  Employee e= mongotemplate.findOne(query2, Employee.class); 
		 
		
		/* Query query2 = Query.query(Criteria.where("empSalary").gte(5000).) */
		
		/* Employee e= mongotemplate.findById(empId, Employee.class); */
		
		
		
		return e;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		
		/*
		 * mongotemplate.updateFirst( new Query(Criteria.where("empId").is(4)),
		 * Update.update("empName", "sai")); return ;
		 */
		
		
		/*
		 * Query query = new Query();
		 * query.addCriteria(Criteria.where("empName").is("lucky"));
		 * query.fields().include("empName");
		 * 
		 * Employee userTest2 = mongotemplate.findOne(query,Employee.class);
		 * System.out.println("userTest2 - " + userTest2);
		 * 
		 * userTest2.setEmpName("bujji");
		 * 
		 * return mongotemplate.save(userTest2);
		 */
		 
		
		 return mongotemplate.save(emp); 
		
	}

	@Override
	public void deleteEmployee(int empId) {
		
	Employee e=	mongotemplate.findById(empId, Employee.class);
		
		mongotemplate.remove(e);
		
	}

}
