import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'; 
@Injectable({
    providedIn:'root'
})

export class EmployeeService{
    constructor(private http:HttpClient){}
    getAllEmployee(){
        return this.http.get("http://localhost:8965/emplist/getalldata");
    }
   addEmployee(data:any){
       let input={"empId":data.id,"empName":data.name,"empSalary":data.salary};
       /* let input = new FormData();
       input.append("empId",data.id);
       input.append("empName",data.name);
       input.append("empSalary",data.salary); */
       return this.http.post("http://localhost:8965/emplist/createdata",input);
   }
}