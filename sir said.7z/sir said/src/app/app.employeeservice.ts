import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { post } from '../../node_modules/@types/selenium-webdriver/http';
@Injectable ({
    

    providedIn: 'root'
})
export class EmployeeService {
    constructor(private http:HttpClient)
    {}
    getAllEmployees(){
        return this.http.get("http://localhost:1009/emplist/getalldata");
    }
    addEmployee(data:any){
        let input = new FormData();
        input.append("empId",data.empId);
        input.append("empName",data.empName);
        input.append("empSalary",data.empSalary);
        return this.http.post("http://localhost:1009/emplist/addemployeedata",data);
    }
}