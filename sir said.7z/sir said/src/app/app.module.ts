﻿import {ShowComponent} from './app.show.component';
import {EmployeeService} from './app.employeeservice';
import { NgModule }      from '@angular/core';


import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {HttpClientModule} from '@angular/common/HTTP';;
import { EmployeeComponent } from './app/employee.component'
import {FormsModule} from '@angular/forms';

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,FormsModule
        
    ],
    declarations: [
        AppComponent,ShowComponent
, EmployeeComponent    ],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }