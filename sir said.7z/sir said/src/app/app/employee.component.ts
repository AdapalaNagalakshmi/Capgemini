import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../app.employeeservice';

@Component({


  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
model:any={};
addEmployee():any{
  console.log(this.model);
this.service.addEmployee(this.model).subscribe();
}
  constructor(private service:EmployeeService) { }

  ngOnInit() {
  }

}
