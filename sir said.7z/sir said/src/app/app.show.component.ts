import {Component} from '@angular/core';
import {EmployeeService} from './app.employeeservice';
@Component({


    selector:'show-app',
    
    
    templateUrl:'app.show.component.html'
})
export class ShowComponent {
    constructor(private service:EmployeeService){}
    ngOnInit(){
        this.service.getAllEmployees().subscribe((data)=>console.log(data));

    }
}