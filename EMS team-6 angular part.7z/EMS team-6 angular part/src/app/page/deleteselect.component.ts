import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-deleteselect',
  templateUrl: './deleteselect.component.html',
  styleUrls: ['./deleteselect.component.css']
})
export class DeleteselectComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  goHome(){
    this.router.navigate(['./menupage']);
  }
  
  onLoadSingle(){
    this.router.navigate(['./loadsingle']);
  }
  
  onLoadBulk(){
    this.router.navigate(['./loadbulk']);
  } 
  
  goLogout(){
    this.router.navigate(['./loginpage']);
  }

  onModify(){
    this.router.navigate(['./modifypage']);
  }
  
  onView(){
    this.router.navigate(['./viewpage']);
  }

  onDeleteSingle(){
    this.router.navigate(['./deletesingle']);
  }

  onSelect(){
    this.router.navigate(['./deleteselect']);
  }
  onSelectAll(){
    this.router.navigate(['./deleteall']);
  }
}
