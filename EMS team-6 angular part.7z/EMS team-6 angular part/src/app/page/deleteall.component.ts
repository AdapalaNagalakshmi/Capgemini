import { Component, OnInit } from '@angular/core';
import { Routes, Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-deleteall',
  templateUrl: './deleteall.component.html',
  styleUrls: ['./deleteall.component.css']
})
export class DeleteallComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  
  onCancel1(){
    this.router.navigate(['/menupage']);
  }

  goHome(){
    this.router.navigate(['./menupage']);
  }
  
  onLoadSingle(){
    this.router.navigate(['./loadsingle']);
  }
  
  onLoadBulk(){
    this.router.navigate(['./loadbulk']);
  } 
  
  goLogout(){
    this.router.navigate(['./loginpage']);
  }

  onModify(){
    this.router.navigate(['./modifypage']);
  }
  
  onView(){
    this.router.navigate(['./viewpage']);
  }

  onDeleteSingle(){
    this.router.navigate(['./deletesingle']);
  }

  onSelect(){
    this.router.navigate(['./deleteselect']);
  }
  
  onSelectAll(){
    this.router.navigate(['./deleteall']);
  }
}
