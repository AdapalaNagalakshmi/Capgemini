import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './page/menu.component';
import{LoadsingleComponent} from './page/loadsingle.component';
import { RegistrationComponent } from './registration.component';
import { LoadbulkComponent } from './page/loadbulk.component';
import { ModifyComponent } from './page/modify.component';
import { ViewComponent } from './page/view.component';
import { DeletesingleComponent } from './page/deletesingle.component';
import { DeleteselectComponent } from './page/deleteselect.component';
import { DeleteallComponent } from './page/deleteall.component';
import { SingleselectnextComponent } from './page/singleselectnext.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuComponent,
    LoadsingleComponent,
    RegistrationComponent,
    LoadbulkComponent,
    ModifyComponent,
    ViewComponent,
    DeletesingleComponent,
    DeleteselectComponent,
    DeleteallComponent,
    SingleselectnextComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
